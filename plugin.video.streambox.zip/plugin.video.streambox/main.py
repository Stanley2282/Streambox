# -*- coding: utf-8 -*-
# Module: default
# Author: cache + Johnysko
# Created on: 10.5.2020(původní zdroj), 24.5.2025(nové funkce)
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import sys
import os


# Přidej cestu k resources/lib do sys.path, aby šlo importovat např. fuzzywuzzy a TMDB moduly
addon_dir = os.path.dirname(os.path.abspath(__file__))
resources_lib = os.path.join(addon_dir, 'resources', 'lib')
if resources_lib not in sys.path:
    sys.path.insert(0, resources_lib)

import streambox

if __name__ == '__main__':
    streambox.router(sys.argv[2][1:])
